class ChangePasswordDigestToArgon2 < ActiveRecord::Migration[6.0]
  def change
    remove_column :users, :password_digest
    add_column :users, :password_digest, :text
  end
end
