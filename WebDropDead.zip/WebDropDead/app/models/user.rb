
class User < ApplicationRecord
    # has_secure_password :argon2
    attr_accessor :username
    attr_accessor :email
    attr_accessor :password
    attr_accessor :password_confirmation
    attr_accessor :quarters
    attr_accessor :white_six_sided_dice
    attr_accessor :overall_points
  

  
    validates :password, presence: true, length: { minimum: 6 }
end
  