
class Game < ApplicationRecord
    validates :number_of_players, :number_of_sides, :number_of_dice, presence: true
  
    def run_auto_drop_dead
      results = roll_dice
  
      # Check if any one was rolled
      if results.include?(1)
        update(result: "You rolled a one! You lose.")
      else
        update(result: "Congratulations! You avoided rolling a one.")
      end
  
      results
    end
  
    private
  
    def roll_dice
      Array.new(number_of_dice) { rand(1..number_of_sides) }
    end
  end
  