# app/controllers/games_controller.rb
class GamesController < ApplicationController
  def new
    @game = Game.new
  end

  
  def create
    @game = Game.new(game_params)

    if @game.save
      @game.run_auto_drop_dead
      render :show
    else
      render :new
    end
  end

  def show
    @game = Game.find(params[:id])
  end

  private

  def game_params
    params.require(:game).permit(:number_of_players, :number_of_sides, :number_of_dice)
  end
end

