class WelcomeController < ApplicationController
  def hello
  end
end
