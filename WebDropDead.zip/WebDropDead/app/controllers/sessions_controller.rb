
class SessionsController < ApplicationController
  def new
  end

  def create
    user = User.find_by(email: params[:email])

    if user && user.authenticate(params[:password])
      if user.user_page_exists?
        redirect_to user_page_path(user)
      else
        redirect_to play_game_path
      end
    else
      flash.now[:alert] = "Invalid email or password"
      render :new
    end
  end

  def destroy
    # Add logout logic if needed
  end
end

