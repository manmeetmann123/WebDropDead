# Example: app/controllers/application_controller.rb
class ApplicationController < ActionController::Base
    def after_sign_in_path_for(resource)
      game_path # Redirect to the game page after sign-in
    end
  end
  